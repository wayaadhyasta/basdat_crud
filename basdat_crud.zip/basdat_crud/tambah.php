<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kata = $_POST['kata'];
    $arti = $_POST['arti'];

    $conn->query(\"INSERT INTO <db_mabel> (kata, arti) VALUES ('$kata', '$arti')\");
    header('Location: index.php');
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Data</title>
</head>
<body>
    <h1>Tambah Data</h1>
    <form method=\"POST\">
        <label>Kata:</label><br>
        <input type=\"text\" name=\"kata\"><br>
        <label>Arti:</label><br>
        <input type=\"text\" name=\"arti\"><br>
        <button type=\"submit\">Simpan</button>
    </form>
</body>
</html>
