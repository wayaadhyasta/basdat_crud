<?php
include 'koneksi.php';

$id = $_GET['id'];
$conn->query(\"DELETE FROM <db_mabel> WHERE id=$id\");
header('Location: index.php');
?>
