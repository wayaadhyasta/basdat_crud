<?php
include 'koneksi.php';

$result = $conn->query("SELECT * FROM <nama_tabel>");
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD PHP</title>
</head>
<body>
    <h1>Data Kamus</h1>
    <a href=\"tambah.php\">Tambah Data</a>
    <table border=\"1\">
        <tr>
            <th>ID</th>
            <th>Kata</th>
            <th>Arti</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['kata'] ?></td>
                <td><?= $row['arti'] ?></td>
                <td>
                    <a href=\"edit.php?id=<?= $row['id'] ?>\">Edit</a>
                    <a href=\"hapus.php?id=<?= $row['id'] ?>\">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>
