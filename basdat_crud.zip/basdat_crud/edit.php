<?php
include 'koneksi.php';

$id = $_GET['id'];
$result = $conn->query(\"SELECT * FROM <db_mabel> WHERE id=$id\");
$data = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kata = $_POST['kata'];
    $arti = $_POST['arti'];

    $conn->query(\"UPDATE <nama_tabel> SET kata='$kata', arti='$arti' WHERE id=$id\");
    header('Location: index.php');
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Data</title>
</head>
<body>
    <h1>Edit Data</h1>
    <form method=\"POST\">
        <label>Kata:</label><br>
        <input type=\"text\" name=\"kata\" value=\"<?= $data['kata'] ?>\"><br>
        <label>Arti:</label><br>
        <input type=\"text\" name=\"arti\" value=\"<?= $data['arti'] ?>\"><br>
        <button type=\"submit\">Simpan</button>
    </form>
</body>
</html>
